"""Core chat template operations: load from HuggingFace and render from string.

``load_hf_chat_template`` fetches original (unmodified) chat templates via
``hf_hub_download``.  Files are cached locally after the first download —
subsequent calls read from disk without network access.

``apply_chat_template_from_str`` renders a Jinja2 chat template string
without depending on a HuggingFace tokenizer, equivalent to
``tokenizer.apply_chat_template(..., tokenize=False)``.

``apply_chat_template`` applies via an HF tokenizer object (returns
``str`` or ``list[int]``).  Both functions normalize tool arguments,
canonicalize tool definitions, and fall back between tool dict formats.
"""

from __future__ import annotations

import copy
import json
from collections.abc import Collection
from typing import Any, Literal

from huggingface_hub import hf_hub_download
from jinja2 import TemplateError
from pydantic import TypeAdapter
from sglang.srt.entrypoints.openai.protocol import Tool
from transformers.utils.chat_template_utils import render_jinja_template

from miles.utils.chat_template_utils import deepseek, inkling

# Message matching moved to message_matcher_hub; direct aliases keep the
# established import surface working without a second implementation.
from miles.utils.chat_template_utils.message_matcher_hub import (  # noqa: F401
    assert_messages_append_only_with_allowed_role,
    strict_message_matches,
)


def load_hf_chat_template(model_id: str) -> str:
    """Load an original chat template from HuggingFace (cached locally).

    Handles two layouts:
    - ``chat_template`` field in ``tokenizer_config.json`` (most models)
    - Separate ``chat_template.jinja`` file (e.g. GLM-5)
    """
    config_path = hf_hub_download(model_id, "tokenizer_config.json")
    with open(config_path) as f:
        config = json.load(f)
    template = config.get("chat_template", "")
    if template:
        if isinstance(template, list):
            for t in template:
                if t.get("name") == "default" or not t.get("name"):
                    return t["template"]
            return template[0]["template"]
        return template

    jinja_path = hf_hub_download(model_id, "chat_template.jinja")
    with open(jinja_path) as f:
        return f.read()


def normalize_tool_arguments(messages: list[dict], format: Literal["dict", "json"]) -> list[dict]:
    """Deep-copy *messages*, normalize assistant ``content: None`` -> "", and coerce
    tool_call ``arguments`` to the form the downstream renderer needs (``format`` picks
    the direction; never mutates the input):
    - ``"dict"``: JSON string -> dict, for HF-Jinja templates (they index args as objects).
    - ``"json"``: dict -> JSON string, for the DeepSeek DSML encoders (they ``json.loads`` them).
    """
    normalized = copy.deepcopy(messages)
    for msg in normalized:
        if msg.get("role") == "assistant":
            if msg.get("content") is None:
                msg["content"] = ""
            if isinstance(msg.get("tool_calls"), list):
                for item in msg["tool_calls"]:
                    func = item.get("function")
                    if not func:
                        continue
                    args = func.get("arguments")
                    if format == "dict" and isinstance(args, str):
                        func["arguments"] = json.loads(args)
                    elif format == "json" and isinstance(args, dict):
                        func["arguments"] = json.dumps(args, ensure_ascii=False)
    return normalized


def extract_tool_dicts(tools: list[dict] | None) -> list[dict] | None:
    """Canonicalize tools via Pydantic, returning full Tool model dumps.

    Matches SGLang's ``_process_messages`` (``serving_chat.py`` lines 343-344):
    ``tools = [item.model_dump() for item in request.tools]`` — each tool is
    a full ``Tool`` model dump (``{"type": "function", "function": {...}}``).
    """
    if not tools:
        return None

    wrapped = [t if isinstance(t, dict) and "function" in t else {"type": "function", "function": t} for t in tools]
    validated = TypeAdapter(list[Tool]).validate_python(wrapped)
    return [tool.model_dump() for tool in validated]


def merge_chat_template_kwargs(
    base: dict[str, Any],
    overrides: dict[str, Any],
    *,
    alias_keys: Collection[str] = (),
) -> dict[str, Any]:
    """Merge one config layer, replacing base aliases as a group."""
    merged = dict(base)
    if any(key in overrides for key in alias_keys):
        for key in alias_keys:
            merged.pop(key, None)
    merged.update(overrides)
    return merged


def apply_chat_template_from_str(
    chat_template: str,
    messages: list[dict],
    add_generation_prompt: bool = True,
    tools: list[dict] | None = None,
    **kwargs,
) -> str:
    """Render a Jinja2 chat template string (tokenize=False, no tokenizer needed).

    Calls HF transformers' ``render_jinja_template`` directly — the same
    function that ``tokenizer.apply_chat_template`` uses internally.  Both
    SGLang and our ``apply_chat_template`` go through that same HF code path.

    Applies SGLang-style normalizations (tool argument parsing, tool dict
    canonicalization, tool format fallback).
    """

    def _render(tool_defs):
        rendered, _ = render_jinja_template(
            conversations=[messages],
            chat_template=chat_template,
            add_generation_prompt=add_generation_prompt,
            tools=tool_defs,
            **kwargs,
        )
        return rendered[0]

    messages = normalize_tool_arguments(messages, "dict")
    tool_defs = extract_tool_dicts(tools)
    try:
        return _render(tool_defs)
    except TemplateError as e:
        if tool_defs is not None:
            try:
                return _render([t["function"] if "function" in t else t for t in tool_defs])
            except TemplateError as te:
                raise ValueError(f"Chat template rendering failed (tool format fallback): {te}") from te
        raise ValueError(f"Chat template rendering failed: {e}") from e


def apply_chat_template(
    messages: list[dict],
    *,
    tokenizer,
    tools: list[dict] | None = None,
    add_generation_prompt: bool = True,
    tokenize: bool = False,
    **kwargs,
) -> str | list[int]:
    """Apply chat template via HF tokenizer in SGLang style.

    Passes ``return_dict=False`` to match SGLang's ``serving_chat.py``,
    ensuring the result is ``str`` (tokenize=False) or ``list[int]``
    (tokenize=True), not a ``BatchEncoding`` or ``dict``.
    """
    if deepseek.model_type(tokenizer) is not None:
        return deepseek.apply_chat_template(
            normalize_tool_arguments(messages, "json"),
            tokenizer,
            tools=tools,
            tokenize=tokenize,
            add_generation_prompt=add_generation_prompt,
            **kwargs,
        )

    if inkling.is_inkling(tokenizer):
        # the fixed template needs parsed tool-call arguments and handles the
        # thinking-effort line, tool_calls, and the end-sampling token itself
        return tokenizer.apply_chat_template(
            normalize_tool_arguments(messages, "dict"),
            chat_template=inkling.fixed_chat_template(),
            tokenize=tokenize,
            tools=extract_tool_dicts(tools),
            return_dict=False,
            add_generation_prompt=add_generation_prompt,
            **kwargs,
        )

    messages = normalize_tool_arguments(messages, "dict")
    tool_defs = extract_tool_dicts(tools)
    render_kwargs = dict(add_generation_prompt=add_generation_prompt, **kwargs)

    try:
        return tokenizer.apply_chat_template(
            messages, tokenize=tokenize, tools=tool_defs, return_dict=False, **render_kwargs
        )
    except TemplateError as e:
        if tool_defs is not None:
            try:
                return tokenizer.apply_chat_template(
                    messages,
                    tokenize=tokenize,
                    tools=[t["function"] if "function" in t else t for t in tool_defs],
                    return_dict=False,
                    **render_kwargs,
                )
            except TemplateError as te:
                raise ValueError(f"Chat template rendering failed (tool format fallback): {te}") from te
        raise ValueError(f"Chat template rendering failed: {e}") from e
