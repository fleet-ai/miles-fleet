from __future__ import annotations

import dataclasses
import gc
import logging
import math
from argparse import Namespace
from collections.abc import Callable, Sequence
from contextlib import nullcontext
from functools import partial
from pathlib import Path

import torch
from megatron.core import mpu
from megatron.core.distributed import DistributedDataParallel as DDP
from megatron.core.distributed import finalize_model_grads
from megatron.core.enums import ModelType
from megatron.core.models.gpt import GPTModel
from megatron.core.optimizer import OptimizerConfig, get_megatron_optimizer
from megatron.core.optimizer.muon import get_megatron_muon_optimizer
from megatron.core.optimizer.optimizer import MegatronOptimizer
from megatron.core.optimizer_param_scheduler import OptimizerParamScheduler
from megatron.core.pipeline_parallel import get_forward_backward_func
from megatron.core.utils import get_model_config
from megatron.training.global_vars import get_args
from megatron.training.training import get_model

from miles.backends.megatron_utils.ft.indep_dp import allreduce_grads_and_losses_across_replicas
from miles.backends.megatron_utils.ft.types import TrainStepOutcome
from miles.backends.megatron_utils.local_weight_checksum import dump_local_weight_checksums
from miles.utils.audit_utils.witness.allocator import WitnessInfo
from miles.utils.audit_utils.witness.module import witness_dump_and_clear_stale
from miles.utils.dumper_utils import DumperMegatronUtil, DumperPhase
from miles.utils.memory_utils import clear_memory
from miles.utils.multi_lora import is_multi_lora_enabled
from miles.utils.test_utils.ft_test_actions import FTTestActionActorExecutor
from miles.utils.tracking_utils.structured_log import log_structured

from ...utils.misc import filter_keys
from ..training_utils.ci_utils import check_grad_norm, check_kl
from ..training_utils.data import DataIterator, get_batch
from ..training_utils.log_utils import aggregate_forward_results, aggregate_train_losses, log_train_step
from ..training_utils.loss import loss_function
from ..training_utils.parallel import get_parallel_state
from .checkpoint import load_checkpoint, save_checkpoint, save_checkpoint_with_lora
from .ci_utils import (
    check_model_hashes,
    check_peak_gpu_memory_after_load,
    compute_model_hashes_by_layer,
    save_model_hashes,
)
from .initialize import is_first_replica_megatron_main_rank
from .lora_utils import is_lora_enabled, is_lora_model
from .model_provider import get_model_provider_func
from .parallel import get_packed_seq_params

logger = logging.getLogger(__name__)


def _has_loadable_ckpt(load_dir: str | None) -> bool:
    """Whether ``--load`` holds anything; ``load_checkpoint`` dispatches dist vs HF itself."""
    return bool(load_dir) and Path(load_dir).is_dir() and any(Path(load_dir).iterdir())


from .bridge_lora_helpers import _ensure_model_list, _setup_lora_model_via_bridge  # noqa: F401


def get_optimizer_param_scheduler(args: Namespace, optimizer: MegatronOptimizer) -> OptimizerParamScheduler:
    """Create and configure the optimizer learning-rate/weight-decay scheduler.

    This configures iteration-based schedules derived from the global batch size
    and run-time arguments.

    Args:
        args (Namespace): Training/runtime arguments (argparse namespace).
        optimizer (MegatronOptimizer): Megatron optimizer bound to the model.

    Returns:
        OptimizerParamScheduler: Initialized scheduler bound to ``optimizer``.
    """
    # Iteration-based training.
    args.train_iters = args.num_rollout * args.rollout_batch_size * args.n_samples_per_prompt // args.global_batch_size
    if args.lr_decay_iters is None:
        args.lr_decay_iters = args.train_iters
    lr_decay_steps = args.lr_decay_iters * args.global_batch_size
    wd_incr_steps = args.train_iters * args.global_batch_size
    wsd_decay_steps = None
    if args.lr_wsd_decay_iters is not None:
        wsd_decay_steps = args.lr_wsd_decay_iters * args.global_batch_size
    if args.lr_warmup_fraction is not None:
        lr_warmup_steps = args.lr_warmup_fraction * lr_decay_steps
    else:
        lr_warmup_steps = args.lr_warmup_iters * args.global_batch_size

    opt_param_scheduler = OptimizerParamScheduler(
        optimizer,
        init_lr=args.lr_warmup_init,
        max_lr=args.lr,
        min_lr=args.min_lr,
        lr_warmup_steps=lr_warmup_steps,
        lr_decay_steps=lr_decay_steps,
        lr_decay_style=args.lr_decay_style,
        start_wd=args.start_weight_decay,
        end_wd=args.end_weight_decay,
        wd_incr_steps=wd_incr_steps,
        wd_incr_style=args.weight_decay_incr_style,
        use_checkpoint_opt_param_scheduler=args.use_checkpoint_opt_param_scheduler,
        override_opt_param_scheduler=args.override_opt_param_scheduler,
        wsd_decay_steps=wsd_decay_steps,
        lr_wsd_decay_style=args.lr_wsd_decay_style,
    )

    return opt_param_scheduler


# ---------------------------------------------------------------------------
# Model + Optimizer setup
# ---------------------------------------------------------------------------


def _is_muon_optimizer(optimizer: str | None) -> bool:
    return optimizer is not None and "muon" in optimizer.lower()


def setup_model_and_optimizer(
    args: Namespace,
    role: str = "actor",
) -> tuple[list[DDP], MegatronOptimizer | None, OptimizerParamScheduler | None]:
    """Build model(s), wrap with DDP, and construct optimizer and scheduler.

    Args:
        args (Namespace): Training/runtime arguments (argparse namespace).
        role (str): Logical role of the model (e.g., "actor", "critic").

    Returns:
        tuple[list[DDP], MegatronOptimizer, OptimizerParamScheduler]:
            - List of model chunks wrapped by ``DDP``.
            - The constructed ``MegatronOptimizer`` instance, or ``None`` when
              ``--debug-disable-optimizer`` is set.
            - The learning-rate/weight-decay scheduler tied to the optimizer, or
              ``None`` when ``--debug-disable-optimizer`` is set.
    """
    assert not args.moe_use_upcycling
    assert args.load is not None or args.pretrained_checkpoint is not None

    # Multi-LoRA and single-LoRA (actor, bridge) both build via the bridge helper,
    # which picks the adapter type internally.
    if is_multi_lora_enabled(args) or (
        is_lora_enabled(args) and role == "actor" and args.megatron_to_hf_mode == "bridge"
    ):
        model = _setup_lora_model_via_bridge(args)
    else:
        provider_func = get_model_provider_func(args, role)
        if (
            is_lora_enabled(args)
            and role == "actor"
            and "inkling" in (getattr(args, "custom_model_provider_path", None) or "")
        ):
            from miles_plugins.models.inkling.lora import wrap_model_provider_with_inkling_lora

            provider_func = wrap_model_provider_with_inkling_lora(provider_func, args)
        model = get_model(provider_func, ModelType.encoder_or_decoder)

    if args.debug_disable_optimizer:
        if is_first_replica_megatron_main_rank():
            logger.warning(
                "Skipping Megatron optimizer and LR scheduler initialization "
                "because --debug-disable-optimizer is set."
            )
        return model, None, None

    # Optimizer
    kwargs = {}
    for f in dataclasses.fields(OptimizerConfig):
        if hasattr(args, f.name):
            kwargs[f.name] = getattr(args, f.name)
    config = OptimizerConfig(**kwargs)
    if args.stream_optimizer_state_to_disk and not _is_muon_optimizer(config.optimizer):
        config.defer_main_param_initialization = True
    config.timers = None

    if _is_muon_optimizer(config.optimizer):
        if args.stream_optimizer_state_to_disk:
            from miles_plugins.optimizers.nvme_stream import setup_muon_state_on_disk

            setup_muon_state_on_disk(args)
        if config.muon_split_qkv and "inkling" in (getattr(args, "custom_model_provider_path", None) or ""):
            if is_first_replica_megatron_main_rank():
                logger.info(
                    "Inkling fused qkvr detected: forcing muon_split_qkv=False " "(whole-matrix orthogonalization)."
                )
            config.muon_split_qkv = False
        optimizer = get_megatron_muon_optimizer(
            config=config,
            model_chunks=model,
            use_gloo_process_groups=args.use_gloo_process_groups,
            layer_wise_distributed_optimizer="dist" in config.optimizer.lower(),
        )
    elif is_multi_lora_enabled(args):
        from miles.backends.megatron_utils.multi_lora_optimizer import build_multi_lora_optimizer

        optimizer = build_multi_lora_optimizer(args, config, model)
    else:
        optimizer = get_megatron_optimizer(
            config=config,
            model_chunks=model,
            use_gloo_process_groups=args.use_gloo_process_groups,
        )

    if args.stream_optimizer_state_to_disk and not _is_muon_optimizer(config.optimizer):
        # Muon took the chunked-offloader route above; this store is DistOpt-only.
        from miles_plugins.optimizers.nvme_stream import setup_optimizer_state_streaming

        setup_optimizer_state_streaming(args, optimizer)

    opt_param_scheduler = get_optimizer_param_scheduler(args, optimizer)
    return model, optimizer, opt_param_scheduler


# ---------------------------------------------------------------------------
# Forward pre-hook helpers
# ---------------------------------------------------------------------------


def enable_forward_pre_hook(model_chunks: Sequence[DDP]) -> None:
    """Enable forward pre-hooks for provided DDP-wrapped model chunks.

    Args:
        model_chunks (Sequence[DDP]): Sequence of DDP modules to enable hooks on.
    """
    for model_chunk in model_chunks:
        assert isinstance(model_chunk, DDP)
        model_chunk.enable_forward_pre_hook()


def disable_forward_pre_hook(model_chunks: Sequence[DDP], param_sync: bool = True) -> None:
    """Disable forward pre-hooks for provided DDP-wrapped model chunks.

    Args:
        model_chunks (Sequence[DDP]): Sequence of DDP modules to disable hooks on.
        param_sync (bool): Whether to synchronize parameters when disabling.
    """
    for model_chunk in model_chunks:
        assert isinstance(model_chunk, DDP)
        model_chunk.disable_forward_pre_hook(param_sync=param_sync)


def should_disable_forward_pre_hook(args: Namespace) -> bool:
    """Block forward pre-hook for certain configurations."""
    return args.use_distributed_optimizer and args.overlap_param_gather


# ---------------------------------------------------------------------------
# Forward-only inference
# ---------------------------------------------------------------------------


@torch.no_grad()
def forward_only(
    f: Callable[..., dict[str, list[torch.Tensor]]],
    args: Namespace,
    model: Sequence[DDP],
    data_iterator: Sequence[DataIterator],
    num_microbatches: Sequence[int],
    rollout_id: int,
    store_prefix: str = "",
    fp32_output: bool = True,
) -> dict[str, list[torch.Tensor]]:
    """Run forward passes only and collect non-loss outputs (e.g., logprobs).

    The model is put into evaluation mode, a forward-only pipeline pass is
    executed, and relevant outputs are aggregated and returned.

    Args:
        f: Post-forward callback used to compute and package outputs to collect.
        args: Runtime arguments.
        model: Sequence of DDP-wrapped model chunks.
        data_iterator: Iterable(s) yielding batches for inference.
        num_microbatches: Number of microbatches per rollout step.
        rollout_id: Rollout identifier (selects the per-rollout dump subdirectory).
        store_prefix: Prefix to prepend to stored output keys.
        fp32_output: Whether Megatron should upcast the complete model output to FP32.

    Returns:
        Aggregated outputs keyed by ``store_prefix + key``.
    """

    dumper_phase_util = DumperMegatronUtil(
        args, model, DumperPhase.FWD_ONLY, rollout_id=rollout_id, store_prefix=store_prefix
    )

    # reset data iterator
    for iterator in data_iterator:
        iterator.reset()

    config = get_model_config(model[0])

    @dumper_phase_util.wrap_forward_step
    def forward_step(
        data_iterator: DataIterator, model: GPTModel, return_schedule_plan: bool = False
    ) -> tuple[torch.Tensor, Callable[[torch.Tensor], dict[str, list[torch.Tensor]]]]:
        """Forward step used by Megatron's pipeline engine.

        Args:
            data_iterator (DataIterator): Input data iterator.
            model (GPTModel): The GPT model chunk to execute.

        Returns:
            tuple[torch.Tensor, Callable[[torch.Tensor], dict[str, list[torch.Tensor]]]]:
            Output tensor(s) and a callable that computes and packages results
            to be collected by the engine.
        """

        assert not return_schedule_plan, "forward_only step should never return schedule plan"

        # Get the batch.
        batch = get_batch(
            data_iterator,
            [
                "tokens",
                "loss_masks",
                "multimodal_train_inputs",
                "total_lengths",
                "response_lengths",
                "max_seq_lens",
                "witness_ids",
            ],
            args.data_pad_size_multiplier,
            args.qkv_format,
            allgather_cp=args.allgather_cp,
        )
        unconcat_tokens = batch["unconcat_tokens"]
        tokens = batch["tokens"]
        packed_seq_params = get_packed_seq_params(batch, args)
        total_lengths = batch["total_lengths"]
        response_lengths = batch["response_lengths"]

        if "adapter_token_counts" in batch:
            from megatron.bridge.peft.multi_lora_layers import set_tokens_per_adapter_slot

            set_tokens_per_adapter_slot(model, batch["adapter_token_counts"])

        output_tensor = model(
            input_ids=tokens,
            position_ids=None,
            attention_mask=None,
            labels=None,
            packed_seq_params=packed_seq_params,
            loss_mask=batch["full_loss_masks"],
            **(filter_keys(batch, ["witness_ids"]) if args.enable_witness else {}),
            **(batch["multimodal_train_inputs"] if batch["multimodal_train_inputs"] is not None else {}),
            fp32_output=fp32_output,
        )

        return output_tensor, partial(
            f,
            args=args,
            unconcat_tokens=unconcat_tokens,
            total_lengths=total_lengths,
            response_lengths=response_lengths,
            with_entropy=args.use_rollout_entropy,
            max_seq_lens=batch.get("max_seq_lens", None),
        )

    # Turn on evaluation mode which disables dropout.
    for model_module in model:
        model_module.eval()

    if args.custom_megatron_before_log_prob_hook_path:
        from miles.utils.misc import load_function

        custom_before_log_prob_hook = load_function(args.custom_megatron_before_log_prob_hook_path)
        custom_before_log_prob_hook(args, model, store_prefix)

    forward_backward_func = get_forward_backward_func()
    # Don't care about timing during evaluation
    config.timers = None
    forward_data_store = []
    num_steps_per_rollout = len(num_microbatches)
    for step_id in range(num_steps_per_rollout):
        # collect_non_loss_data
        forward_data_store += forward_backward_func(
            forward_step_func=forward_step,
            data_iterator=data_iterator,
            model=model,
            num_microbatches=num_microbatches[step_id],
            seq_length=args.seq_length,
            micro_batch_size=args.micro_batch_size,
            forward_only=True,
            collect_non_loss_data=True,
        )

    # Move model back to the train mode.
    for model_module in model:
        model_module.train()

    dumper_phase_util.finalize(model)

    rollout_data = {}
    # Store the results on the last stage
    if mpu.is_pipeline_last_stage():
        aggregated = aggregate_forward_results(forward_data_store, data_iterator[0], args, store_prefix="")
        for key, value in aggregated.items():
            rollout_data[f"{store_prefix}{key}"] = value
    return rollout_data


def _zero_grads(model: Sequence[DDP], optimizer: MegatronOptimizer | None, disable_optimizer: bool) -> None:
    for model_chunk in model:
        model_chunk.zero_grad_buffer()
    if not disable_optimizer:
        optimizer.zero_grad()


def train_one_step(
    args: Namespace,
    rollout_id: int,
    step_id: int,
    data_iterator: Sequence[DataIterator],
    model: Sequence[DDP],
    optimizer: MegatronOptimizer | None,
    opt_param_scheduler: OptimizerParamScheduler | None,
    num_microbatches: int,
    num_rollouts: int,
    witness_info: WitnessInfo | None,
    attempt: int,
    ft_test_action_executor: FTTestActionActorExecutor | None = None,
) -> tuple[dict[str, float], float, TrainStepOutcome]:
    """Execute a single pipeline-parallel training step.

    Runs forward/backward over ``num_microbatches``, applies optimizer step and
    one scheduler step when gradients are valid.

    Multi-LoRA: gradients are retained across train calls (per-adapter
    gradient accumulation); only the slots in the batch's ``step_slots`` step,
    and only their gradients are zeroed.

    Args:
        args: Runtime arguments.
        rollout_id: Rollout identifier.
        step_id: Step index within the current rollout.
        data_iterator: Iterable(s) yielding training batches.
        model: Sequence of DDP-wrapped model chunks.
        optimizer: Optimizer instance.
        opt_param_scheduler: LR/WD scheduler.
        num_microbatches: Number of microbatches to process.
        num_rollouts: This step's rollout count (loss normalizer + LR increment).

    Returns:
        Tuple of (reduced loss dict, gradient norm, step outcome).
    """
    args = get_args()
    parallel_state = get_parallel_state()
    dumper_phase_util = DumperMegatronUtil(args, model, DumperPhase.FWD_BWD, rollout_id=rollout_id)
    disable_optimizer = args.debug_disable_optimizer or optimizer is None
    multi_lora = is_multi_lora_enabled(args)

    if multi_lora:
        from miles.backends.megatron_utils.multi_lora_optimizer import reset_grad_metadata_keep_grads

        # Retain accumulated per-adapter gradients; reset only the per-iteration
        # DDP bookkeeping. Slot grads are zeroed selectively at step time.
        reset_grad_metadata_keep_grads(model)
    else:
        _zero_grads(model, optimizer, disable_optimizer)

    if args.custom_megatron_before_train_step_hook_path:
        from miles.utils.misc import load_function

        custom_before_train_step_hook = load_function(args.custom_megatron_before_train_step_hook_path)
        custom_before_train_step_hook(args, rollout_id, step_id, model, optimizer, opt_param_scheduler)

    @dumper_phase_util.wrap_forward_step
    def forward_step(data_iterator: DataIterator, model: GPTModel, return_schedule_plan: bool = False) -> tuple[
        torch.Tensor,
        Callable[[torch.Tensor], tuple[torch.Tensor, int, dict[str, torch.Tensor | list[str]]]],
    ]:
        """Forward step used by Megatron's pipeline engine during training.

        Args:
            data_iterator (DataIterator): Input data iterator.
            model (GPTModel): The GPT model chunk to execute.

        Returns:
            tuple[torch.Tensor, Callable[[torch.Tensor], tuple[torch.Tensor, int, dict[str, torch.Tensor | list[str]]]]]:
            Output tensor(s) and the loss function, which returns
            (loss, num_elems, {"keys": list[str], "values": torch.Tensor}).
        """

        # Get the batch.
        batch = get_batch(
            data_iterator,
            [
                "tokens",
                "multimodal_train_inputs",
                "packed_seq_params",
                "total_lengths",
                "response_lengths",
                "loss_masks",
                "log_probs",
                "ref_log_probs",
                "values",
                "advantages",
                "returns",
                "rollout_log_probs",
                "max_seq_lens",
                "witness_ids",
                "opd_reverse_kl",
                "rollout_mask_sums",
            ],
            args.data_pad_size_multiplier,
            args.qkv_format,
            allgather_cp=args.allgather_cp,
        )

        if "adapter_token_counts" in batch:
            from megatron.bridge.peft.multi_lora_layers import set_tokens_per_adapter_slot

            set_tokens_per_adapter_slot(model, batch["adapter_token_counts"])

        from miles.utils.replay_base import all_replay_managers

        old_stages = [m.stage for m in all_replay_managers]
        for m in all_replay_managers:
            m.stage = "replay_forward"

        if return_schedule_plan:
            assert not args.enable_mtp_training, "MTP training should not be enabled when using combined 1f1b"
            assert not args.enable_witness, "Witness is not supported with combined 1f1b (build_schedule_plan)"
            output_tensor = model.build_schedule_plan(
                input_ids=batch["tokens"],
                position_ids=None,
                attention_mask=None,
                labels=None,
                packed_seq_params=get_packed_seq_params(batch, args),
                loss_mask=batch["full_loss_masks"],
            )
        else:
            forward_kwargs = {
                "input_ids": batch["tokens"],
                "position_ids": None,
                "attention_mask": None,
                "labels": None,
                "packed_seq_params": get_packed_seq_params(batch, args),
                "loss_mask": batch["full_loss_masks"],
                **(filter_keys(batch, ["witness_ids"]) if args.enable_witness else {}),
            }

            if (x := batch["multimodal_train_inputs"]) is not None:
                forward_kwargs.update(x)

            output_tensor = model(**forward_kwargs, fp32_output=args.loss_type not in ("policy_loss", "sft_loss"))

        for m, old_stage in zip(all_replay_managers, old_stages, strict=True):
            m.stage = old_stage

        return output_tensor, partial(
            loss_function,
            args,
            batch,
            num_microbatches,
            apply_megatron_loss_scaling=True,
            num_rollouts=num_rollouts,
        )

    # Forward pass.
    forward_backward_func = get_forward_backward_func()
    losses_reduced = forward_backward_func(
        forward_step_func=forward_step,
        data_iterator=data_iterator,
        model=model,
        num_microbatches=num_microbatches,
        seq_length=args.seq_length,
        micro_batch_size=args.micro_batch_size,
        decoder_seq_length=args.decoder_seq_length,
        forward_only=False,
    )

    outcome = TrainStepOutcome.NORMAL
    grad_norm = 0.0
    valid_step = True
    indep_dp_loss_reduced: dict[str, float] = {}

    if parallel_state.indep_dp.size > 1:
        assert step_id == 0, "indep-dp does not support multi step per train yet"

        if ft_test_action_executor is not None:
            ft_test_action_executor.maybe_crash(rollout_id=rollout_id, attempt=attempt)

        metric_num_rollouts = None if args.calculate_per_token_loss else num_rollouts
        ok, indep_dp_loss_reduced = allreduce_grads_and_losses_across_replicas(
            args, model, parallel_state, losses_reduced=losses_reduced, num_rollouts=metric_num_rollouts
        )
        if not ok:
            outcome = TrainStepOutcome.DISCARDED_SHOULD_RETRY
            valid_step = False

    if (not disable_optimizer) and (not multi_lora) and (not getattr(args, "check_for_nan_in_loss_and_grad", True)):
        found_inf_flag = optimizer.prepare_grads()
        if found_inf_flag:
            valid_step = False
        else:
            grad_norm = optimizer.get_grad_norm()
            if isinstance(grad_norm, torch.Tensor):
                valid_step = not (torch.isnan(grad_norm) or torch.isinf(grad_norm))
            else:
                valid_step = not (math.isnan(grad_norm) or math.isinf(grad_norm))

    # CI check: verify only MTP parameters have non-zero gradients when truncation happens
    # This check must happen before optimizer.step() as gradients may be modified during step
    if args.ci_test and args.enable_mtp_training and args.rollout_max_response_len <= 128:
        # under response length <= 128, all outputs are truncated and loss mask is all zeros, so only MTP parameters have non-zero gradients
        from miles.backends.megatron_utils.ci_utils import check_mtp_only_grad

        check_mtp_only_grad(model, step_id)

    # Dump backward tensors while gradients are still attached. The optimizer
    # step and subsequent zero_grad release them.
    if outcome == TrainStepOutcome.NORMAL:
        dumper_phase_util.finalize(model)

    if not disable_optimizer and valid_step:
        if multi_lora:
            from miles.backends.megatron_utils.multi_lora_utils import step_stepped_adapter_slots

            grad_norm = step_stepped_adapter_slots(
                args, model, optimizer, data_iterator[0].rollout_data, rollout_id, step_id
            )
        else:
            # Update parameters.
            update_successful, grad_norm, num_zeros_in_grad = optimizer.step()

            # Update learning rate.
            assert update_successful
            opt_param_scheduler.step(increment=num_rollouts)

    # release grad (multi-LoRA retains accumulated grads; stepped slots were
    # zeroed selectively inside step_adapter_slots)
    if not multi_lora:
        _zero_grads(model, optimizer, disable_optimizer)

    log_structured(
        logger.info,
        op="train_step",
        rollout=rollout_id,
        step=step_id,
        attempt=attempt,
        outcome=outcome.name,
        valid_step=valid_step,
    )

    if outcome == TrainStepOutcome.NORMAL:
        dump_local_weight_checksums(args=args, model=model, optimizer=optimizer)
        if args.enable_witness:
            witness_dump_and_clear_stale(model=model, witness_info=witness_info, optimizer=optimizer)

        if mpu.is_pipeline_last_stage(ignore_virtual=True):
            metric_num_rollouts = None if args.calculate_per_token_loss else num_rollouts
            loss_reduced = (
                indep_dp_loss_reduced
                if parallel_state.indep_dp.size > 1
                else aggregate_train_losses(losses_reduced, metric_num_rollouts)
            )
            return loss_reduced, grad_norm, outcome

    return {}, grad_norm, outcome


def finalize_model_grads_with_empty_cache(*args, **kwargs):
    # TODO: this is an ad-hoc method and we should figure out why the oom happens in the first place.
    device = torch.cuda.current_device()
    free, total = torch.cuda.mem_get_info(device)
    if free / total < 0.1:
        clear_memory()
    from .lora_utils import reduce_marked_lora_grads

    reduce_marked_lora_grads(args[0])
    return finalize_model_grads(*args, **kwargs)


def train(
    rollout_id: int,
    model: Sequence[DDP],
    optimizer: MegatronOptimizer | None,
    opt_param_scheduler: OptimizerParamScheduler | None,
    data_iterator: Sequence[DataIterator],
    num_microbatches: Sequence[int],
    num_rollouts: Sequence[int],
    witness_info: WitnessInfo | None,
    attempt: int,
    ft_test_action_executor: FTTestActionActorExecutor | None = None,
) -> TrainStepOutcome:
    """Run training over a rollout consisting of multiple steps.

    The model is switched to train mode, training hooks are configured, and
    ``train_one_step`` is invoked for each step in the rollout.

    Args:
        rollout_id (int): Rollout identifier.
        model (Sequence[DDP]): Sequence of DDP-wrapped model chunks.
        optimizer (MegatronOptimizer): Optimizer instance.
        opt_param_scheduler (OptimizerParamScheduler): LR/WD scheduler.
        data_iterator (Sequence[DataIterator]): Iterable(s) yielding training batches.
        num_microbatches (Sequence[int]): Microbatches per step in the rollout.
        num_rollouts (Sequence[int]): Rollout count per step (total across DP).
    """
    parallel_state = get_parallel_state()
    args = get_args()
    disable_optimizer = args.debug_disable_optimizer or optimizer is None

    assert len(num_microbatches) == len(num_rollouts), (
        f"num_microbatches and num_rollouts must have the same length, "
        f"got {len(num_microbatches)} vs {len(num_rollouts)}"
    )

    for iterator in data_iterator:
        iterator.reset()

    # Turn on training mode which enables dropout.
    for model_module in model:
        model_module.train()

    # Setup some training config params.
    config = get_model_config(model[0])
    config.grad_scale_func = None if disable_optimizer else optimizer.scale_loss
    config.timers = None
    if isinstance(model[0], DDP) and args.overlap_grad_reduce:
        assert config.no_sync_func is None, (
            "When overlap_grad_reduce is True, config.no_sync_func must be None; "
            "a custom no_sync_func is not supported when overlapping grad-reduce"
        )
        config.no_sync_func = [model_chunk.no_sync for model_chunk in model]
        if len(model) == 1:
            config.no_sync_func = config.no_sync_func[0]
        if args.align_grad_reduce:
            config.grad_sync_func = [model_chunk.start_grad_sync for model_chunk in model]
            if len(model) == 1:
                config.grad_sync_func = config.grad_sync_func[0]
    if args.overlap_param_gather and args.align_param_gather:
        config.param_sync_func = [model_chunk.start_param_sync for model_chunk in model]
        if len(model) == 1:
            config.param_sync_func = config.param_sync_func[0]
    config.finalize_model_grads_func = finalize_model_grads_with_empty_cache

    pre_hook_enabled = False

    if args.reset_optimizer_states and not disable_optimizer:
        if is_first_replica_megatron_main_rank():
            print("Reset optimizer states")
        for chained_optimizer in optimizer.chained_optimizers:
            for group in chained_optimizer.optimizer.param_groups:
                if "step" in group:
                    group["step"] = 0
            for state in chained_optimizer.optimizer.state.values():
                if "exp_avg" in state:
                    state["exp_avg"].zero_()
                if "exp_avg_sq" in state:
                    state["exp_avg_sq"].zero_()

    if args.manual_gc:
        # Disable the default garbage collector and perform the collection manually.
        # This is to align the timing of garbage collection across ranks.
        assert args.manual_gc_interval >= 0, "Manual garbage collection interval should be larger than or equal to 0"
        gc.disable()
        gc.collect()

    # Disable forward pre-hook to start training to ensure that errors in checkpoint loading
    # or random initialization don't propagate to all ranks in first all-gather (which is a
    # no-op if things work correctly).
    if should_disable_forward_pre_hook(args):
        disable_forward_pre_hook(model, param_sync=False)
        # Also remove param_sync_func temporarily so that sync calls made in
        # `forward_backward_func` are no-ops.
        param_sync_func = config.param_sync_func
        config.param_sync_func = None
        pre_hook_enabled = False

    num_steps_per_rollout = len(num_microbatches)
    if parallel_state.indep_dp.size > 1:
        assert num_steps_per_rollout == 1, "indep_dp is incompatible with num_steps_per_rollout>1 currently"

    # Run training iterations till done.
    for step_id in range(num_steps_per_rollout):

        # Run training step.
        loss_dict, grad_norm, train_step_outcome = train_one_step(
            args,
            rollout_id,
            step_id,
            data_iterator,
            model,
            optimizer,
            opt_param_scheduler,
            num_microbatches[step_id],
            num_rollouts[step_id],
            witness_info=witness_info,
            attempt=attempt,
            ft_test_action_executor=ft_test_action_executor,
        )

        if step_id == 0:
            # Enable forward pre-hook after training step has successfully run. All subsequent
            # forward passes will use the forward pre-hook / `param_sync_func` in
            # `forward_backward_func`.
            if should_disable_forward_pre_hook(args):
                enable_forward_pre_hook(model)
                config.param_sync_func = param_sync_func
                pre_hook_enabled = True

        mtp_losses = None
        if args.enable_mtp_training:
            from megatron.core.transformer.multi_token_prediction import MTPLossLoggingHelper

            mtp_loss_scale = 1.0 if args.calculate_per_token_loss else 1 / num_microbatches[step_id]
            MTPLossLoggingHelper.reduce_loss_in_tracker()
            tracker = MTPLossLoggingHelper.tracker
            # here we assume only one mtp layer
            if "values" in tracker:
                mtp_losses = (tracker["values"] * mtp_loss_scale).item()
            elif "loss_values" in tracker:
                mtp_losses = (tracker["loss_values"] * mtp_loss_scale).item()

            if mtp_losses is not None:
                MTPLossLoggingHelper.clean_loss_in_tracker()

                # CI check: verify MTP loss is within expected bounds
                if args.ci_test:
                    from miles.backends.megatron_utils.ci_utils import check_mtp_loss

                    check_mtp_loss(mtp_losses)

        # per train step log.
        if (train_step_outcome == TrainStepOutcome.NORMAL) and is_first_replica_megatron_main_rank():
            accumulated_step_id = rollout_id * num_steps_per_rollout + step_id
            role = getattr(model[0], "role", "actor")
            role_tag = "" if role == "actor" else f"{role}-"

            extra_metrics = {}
            if args.enable_mtp_training and mtp_losses is not None:
                extra_metrics["mtp_loss"] = mtp_losses

            if not disable_optimizer:
                for param_group_id, param_group in enumerate(optimizer.param_groups):
                    extra_metrics[f"lr-pg_{param_group_id}"] = opt_param_scheduler.get_lr(param_group)

            log_dict = log_train_step(
                args=args,
                loss_dict=loss_dict,
                grad_norm=grad_norm,
                rollout_id=rollout_id,
                step_id=step_id,
                num_steps_per_rollout=num_steps_per_rollout,
                role=role,
                extra_metrics=extra_metrics,
                should_log=True,
            )

            if args.ci_test and not args.ci_disable_kl_checker:
                check_kl(args, log_dict, step_id, accumulated_step_id)

            logger.info(f"{role_tag}step {accumulated_step_id}: {log_dict}")

            if args.ci_test:
                check_grad_norm(
                    args=args,
                    grad_norm=grad_norm,
                    rollout_id=rollout_id,
                    step_id=step_id,
                    role=role,
                    rank=parallel_state.effective_dp.rank,
                )

    # Close out pre-hooks if using distributed optimizer and overlapped param gather.
    if pre_hook_enabled:
        disable_forward_pre_hook(model)

    return train_step_outcome


def save(
    iteration: int,
    model: Sequence[DDP],
    optimizer: MegatronOptimizer | None,
    opt_param_scheduler: OptimizerParamScheduler | None,
    checkpointing_context: dict | None = None,
    non_persistent_ckpt: bool = False,
) -> None:
    """Persist a training checkpoint safely with forward hooks disabled.

    Args:
        iteration (int): Current global iteration number.
        model (Sequence[DDP]): Sequence of DDP-wrapped model chunks.
        optimizer (MegatronOptimizer): Optimizer instance.
        opt_param_scheduler (OptimizerParamScheduler): LR/WD scheduler.
        checkpointing_context (dict | None): Context passed to Megatron's save_checkpoint
            (e.g. ``{'local_checkpoint_manager': manager}`` for in-memory checkpoints).
        non_persistent_ckpt (bool): If True, save a non-persistent (in-memory) checkpoint.
    """
    args = get_args()
    hashes = None
    if args.ci_test and args.ci_save_model_hash:
        hashes = compute_model_hashes_by_layer(model)
    if should_disable_forward_pre_hook(args):
        disable_forward_pre_hook(model)

    if is_lora_model(model):
        save_checkpoint_with_lora(iteration, model, optimizer, opt_param_scheduler)
    else:
        save_checkpoint(
            iteration,
            model,
            optimizer,
            opt_param_scheduler,
            num_floating_point_operations_so_far=0,
            train_data_iterator=None,
            preprocess_common_state_dict_fn=None,
            checkpointing_context=checkpointing_context,
            non_persistent_ckpt=non_persistent_ckpt,
        )

    if hashes is not None:
        save_model_hashes(args, model, iteration, hashes)
    if should_disable_forward_pre_hook(args):
        enable_forward_pre_hook(model)


def initialize_model_and_optimizer(
    args: Namespace,
    role: str = "actor",
    checkpointing_context=None,
) -> tuple[list[DDP], MegatronOptimizer | None, OptimizerParamScheduler | None, int]:
    """Initialize model(s), optimizer, scheduler, and load from checkpoint.

    Args:
        args (Namespace): Runtime arguments.
        role (str): Logical role of the model (e.g., "actor", "critic").
        checkpointing_context: pass-through checkpointing context

    Returns:
        tuple[list[DDP], MegatronOptimizer, OptimizerParamScheduler, int]:
            DDP-wrapped model chunks, optimizer, scheduler, and iteration index.
    """
    model, optimizer, opt_param_scheduler = setup_model_and_optimizer(args, role)
    model[0].role = role
    clear_memory()

    if is_multi_lora_enabled(args):
        # Hide adapter params so the bridge's conversion-task walk doesn't see them
        # while loading the base checkpoint.
        from megatron.bridge.peft.multi_lora_layers import hide_adapters

        load_ctx = hide_adapters(model)
    else:
        load_ctx = nullcontext()

    load_dir = getattr(args, "load", None)
    # --load may be unset: setup_model_and_optimizer already asserted pretrained_checkpoint covers it.
    if load_dir is None or _has_loadable_ckpt(load_dir):
        with load_ctx:
            iteration, _ = load_checkpoint(
                model,
                optimizer,
                opt_param_scheduler,
                checkpointing_context=checkpointing_context,
                skip_load_to_model_and_opt=False,
            )
    else:
        if is_first_replica_megatron_main_rank():
            logger.warning("--load %r is empty; starting from model_provider-initialized weights", load_dir)
        iteration = 0

    if (
        is_lora_enabled(args)
        and role == "actor"
        and args.megatron_to_hf_mode != "bridge"
        and getattr(args, "lora_adapter_path", None)
        and "inkling" in (getattr(args, "custom_model_provider_path", None) or "")
    ):
        if (Path(args.lora_adapter_path) / "adapter_model.safetensors").exists():
            from miles_plugins.models.inkling.lora import load_inkling_lora_adapter

            load_inkling_lora_adapter(model, args.lora_adapter_path)
            if optimizer is not None:
                # refresh the fp32 masters, or the first step() restores the
                # pre-load init values over the adapter we just wrote
                optimizer.reload_model_params()

    check_peak_gpu_memory_after_load(args)
    clear_memory()

    check_model_hashes(args, model, iteration)

    # Megatron checkpoint loads can restore scheduler state directly. In that
    # case, stepping by the checkpoint iteration here would double-count.
    if opt_param_scheduler is not None and not (args.use_checkpoint_opt_param_scheduler and iteration > 0):
        opt_param_scheduler.step(increment=iteration * args.global_batch_size)

    return model, optimizer, opt_param_scheduler, iteration
