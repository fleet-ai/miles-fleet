import os
import re

import torch

from miles.utils.fp8_kernel import blockwise_cast_to_fp8_triton

from ...sglang import (
    per_block_cast_to_fp8,
    quant_weight_ue8m0,
    should_deepgemm_weight_requant_ue8m0,
    transform_scale_ue8m0,
)


def quantize_params_fp8(args, megatron_name, converted_named_params, quantization_config):
    assert quantization_config["quant_method"] == "fp8"
    fmt = quantization_config.get("fmt", "e4m3")
    assert fmt == "e4m3", f"Unsupported FP8 format: {fmt}"
    assert quantization_config["activation_scheme"] == "dynamic"
    weight_block_size = quantization_config.get("weight_block_size", None)

    decoder_layers_pattern = r"module\.module\.decoder\.layers\.(\d+)\.(.+)"
    match = re.match(decoder_layers_pattern, megatron_name)

    if not match:
        # check mtp layers
        mtp_layer_pattern = r"module\.module\.mtp\.layers\.(\d+)\.(.+)"
        match = re.match(mtp_layer_pattern, megatron_name)
        if not match:
            return converted_named_params
        layer_idx, rest = match.groups()
        rest = rest.replace("transformer_layer.", "").replace("mtp_model_layer.", "")
    else:
        layer_idx, rest = match.groups()

    # experts
    expert_pattern = r"mlp.experts\.(.+)\.weight(\d+)"
    match = re.match(expert_pattern, rest)
    if match:
        rest, expert_idx = match.groups()
        if rest in [
            "linear_fc1",
            "linear_fc2",
        ]:
            quantize_named_params = []
            for converted_name, param in converted_named_params:
                # skip bf16 weight_scale and input_scale
                # TODO: find a clearer way.
                if converted_name.endswith("_scale"):
                    continue
                quantize_named_params.extend(_quantize_param(args, converted_name, param, weight_block_size))

            return quantize_named_params

    # shared expert
    shared_expert_pattern = r"mlp.shared_experts\.(.+)"
    match = re.match(shared_expert_pattern, rest)
    if match:
        rest = match.groups()[0]
        if rest in [
            "linear_fc1.weight",
            "linear_fc2.weight",
        ]:
            quantize_named_params = []
            for converted_name, param in converted_named_params:
                quantize_named_params.extend(_quantize_param(args, converted_name, param, weight_block_size))

            return quantize_named_params

    fp8_param_names = [
        "self_attention.linear_proj.weight",
        "self_attention.linear_qkv.weight",
        "mlp.linear_fc1.weight",
        "mlp.linear_fc2.weight",
        # mla
        "self_attention.linear_q_proj.weight",
        "self_attention.linear_q_down_proj.weight",
        "self_attention.linear_q_up_proj.weight",
        "self_attention.linear_kv_down_proj.weight",
        "self_attention.linear_kv_up_proj.weight",
        # DSA indexer
        "self_attention.wq_b.weight",
        # linear attention
        "self_attention.linear_attn.in_proj_qkv.weight",
        "self_attention.linear_attn.in_proj_z.weight",
        "self_attention.linear_attn.out_proj.weight",
        # DeepSeek V4 attention
        "self_attention.linear_kv_proj.weight",
        "self_attention.core_attention.indexer.linear_wq_b.weight",
    ]
    if not getattr(args, "indexer_rope_interleave", False):
        # Non-interleaved indexers keep wk as a standalone FP8 parameter in SGLang.
        fp8_param_names.extend(
            [
                "self_attention.wk.weight",
                "self_attention.core_attention.indexer.linear_wk.weight",
            ]
        )

    if rest in fp8_param_names:
        quantize_named_params = []
        for converted_name, param in converted_named_params:
            quantize_named_params.extend(_quantize_param(args, converted_name, param, weight_block_size))

        return quantize_named_params

    # for other parameters, we just return the original converted_named_params
    return converted_named_params


def _quantize_param(args, name, weight, weight_block_size):
    assert name.endswith(".weight"), f"Expected weight parameter, got {name}"
    FP8_MIN = torch.finfo(torch.float8_e4m3fn).min
    FP8_MAX = torch.finfo(torch.float8_e4m3fn).max
    if weight_block_size is not None:
        if _get_scale_format(args, name, weight_block_size) == "ue8m0":
            qweight, scale = quant_weight_ue8m0(weight, weight_block_size=weight_block_size)
            scale = transform_scale_ue8m0(scale, mn=qweight.shape[-2])
        # TODO: this [128, 128] is hacky. need improve
        elif (
            os.environ["NVTE_FP8_BLOCK_SCALING_FP32_SCALES"] == "0"
            and per_block_cast_to_fp8 is not None
            and list(weight_block_size) == [128, 128]
        ):
            qweight, scale = per_block_cast_to_fp8(weight)
        else:
            qweight, scale = blockwise_cast_to_fp8_triton(weight, weight_block_size)
        scale_name = name.replace(".weight", ".weight_scale_inv")
    else:
        # per tensor quant
        scale = weight.abs().max().clamp(min=1e-12).to(torch.float32) / FP8_MAX
        qweight = (weight / scale).clamp(min=FP8_MIN, max=FP8_MAX).to(torch.float8_e4m3fn)
        scale = scale.view(1)
        scale_name = name.replace(".weight", ".weight_scale")
    return [(name, qweight), (scale_name, scale)]


def _get_scale_format(args, name, weight_block_size):
    if not (
        should_deepgemm_weight_requant_ue8m0
        and should_deepgemm_weight_requant_ue8m0(weight_block_size=weight_block_size)
    ):
        return None  # use default fp32 scale format

    if ".experts." not in name:
        # Non-MoE linear weights: ue8m0 when deepgemm is enabled
        return "ue8m0"

    # MoE expert weights: only ue8m0 when runner is deep_gemm
    is_deepgemm_moe_backend = args.sglang_moe_runner_backend == "deep_gemm" or (
        args.sglang_moe_runner_backend == "auto" and args.sglang_moe_a2a_backend in ["deepep", "mooncake"]
    )
    return "ue8m0" if is_deepgemm_moe_backend else None
